package com.example.lab2genser
//Genser Catalan - 23401
//Universidad del Valle de Guatemala
//Programacion de plataformas moviles

val listaNumero: MutableList<Int> = mutableListOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
val listaEnteros: MutableList<Int> = mutableListOf(7, 5, 3, 7, 10, 27, 77, 9, 5)
val listaNombres: MutableList<String> = mutableListOf("Juan", "Maria", "Pedro", "Ana")

//Funsion inciso 1
fun calcularPromedio(listaNumero: List<Int>): Double {
    var sum = 0.0
    for (numero in listaNumero) {
        sum += numero
    }
    return sum / listaNumero.size
}

//Funsion inciso 2
fun numerosImpares(listaEnteros: List<Int>): List<Int> {
    return listaEnteros.filter { it % 2 != 0 }
}

//Funsion inciso 3
fun isPalindrome(cadena: String): Boolean {
    return cadena == cadena.reversed()
}

//Funsion inciso 4
fun Saludos(listaNombres: List<String>): List<String> {
    return listaNombres.map { "¡¡¡Hola, $it!!!" }
}

//Funsion inciso 5
fun performOperation(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
    return operation(a, b)
}

data class Person(val name: String, val age: Int, val gender: String)
data class Student(val name: String, val age: Int, val gender: String, val studentId: String)

//Funsion inciso 6
fun mapPersonToStudent(persons: List<Person>): List<Student> {
    return persons.mapIndexed { index, person ->
        Student(person.name, person.age, person.gender, "ID${index + 1}")
    }
}

fun main() {
    // Ejercicio 1
    println("\n Inciso 1 \n")
    val promedio = calcularPromedio(listaNumero)
    println("El promedio de los números es: $promedio")

    // Ejercicio 2
    println("\n Inciso 2 \n")
    val cantidadImpares = numerosImpares(listaEnteros)
    println("La cantidad de números impares es: $cantidadImpares")

    // Ejercicio 3
    println("\n Inciso 3 \n")
    val esPalindromo = isPalindrome("oso")
    println("La palabra 'oso' es un palíndromo? $esPalindromo")

    // Ejercicio 4
    println("\n Inciso 4 \n")
    val saludos = Saludos(listaNombres)
    println(saludos)

    // Ejercicio 5
    println("\n Inciso 5 \n")
    val suma = performOperation(7, 8) { a, b -> a + b }
    val resta = performOperation(7, 8) { a, b -> a - b }
    println("La suma de 7 y 8 es: $suma")
    println("La resta de 7 y 8 es: $resta")

    // Ejercicio 6
    println("\n Inciso 6 \n")
    val persons = listOf(
        Person("Juan", 22, "Masculino"),
    )

    val students = mapPersonToStudent(persons)
    students.forEach {
        println("El Estudiante ${it.name} tiene ${it.age} años y su ID es ${it.studentId}")
    }
}
